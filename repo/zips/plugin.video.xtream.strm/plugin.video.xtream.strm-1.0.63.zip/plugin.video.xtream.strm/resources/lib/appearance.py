# -*- coding: utf-8 -*-

import json
import os
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from common import ADDON_PROFILE


ARCTIC_ZEPHYR_RELOADED_ID = "skin.arctic.zephyr.mod"
ARCTIC_ZEPHYR_RELOADED_NAME = "Arctic: Zephyr - Reloaded"
YOUTUBE_ADDON_ID = "plugin.video.youtube"
YOUTUBE_ADDON_NAME = "YouTube"
SKINSHORTCUTS_ID = "script.skinshortcuts"
SKIN_SETUP_STATE_FILE = "skin_setup_state.json"

MAINMENU_ALLOWED_DEFAULT_IDS = ("movies", "tvshows", "livetv", "settings", "power")
MAINMENU_ALLOWED_LABELS = ("serien", "tv shows", "tvshows", "live tv", "livetv")

MOVIE_WIDGETS = (
    {
        "label_id": "20342",
        "suffix": "",
        "name": "Neue Filme",
        "widget": "NewMovies",
        "path": "special://skin/extras/playlists/NewMovies.xsp",
        "target": "video",
        "aspect": "Poster",
    },
    {
        "label_id": "20342",
        "suffix": ".2",
        "name": "Filme fortsetzen",
        "widget": "InProgressMovies",
        "path": "special://skin/extras/playlists/InProgressMovies.xsp",
        "target": "video",
        "aspect": "Poster",
    },
)

TV_WIDGETS = (
    {
        "label_id": "tvshows",
        "suffix": "",
        "name": "Serien fortsetzen",
        "widget": "InProgress",
        "path": "special://skin/extras/playlists/InProgressTvShows.xsp",
        "target": "video",
        "aspect": "Poster",
    },
    {
        "label_id": "tvshows",
        "suffix": ".2",
        "name": "Naechste Folgen",
        "widget": "InProgressEpisodes",
        "path": "special://skin/extras/playlists/InProgressEpisodes.xsp",
        "target": "video",
        "aspect": "Poster",
    },
    {
        "label_id": "tvshows",
        "suffix": ".3",
        "name": "Neue Serien",
        "widget": "NewTvShows",
        "path": "special://skin/extras/playlists/NewShows.xsp",
        "target": "video",
        "aspect": "Poster",
    },
)

SETTINGS_WIDGETS = (
    {
        "label_id": "settings",
        "suffix": "",
        "name": "Xtream IPTV Ultimate",
        "widget": "addon",
        "path": "plugin://plugin.video.xtream.strm/",
        "target": "video",
        "aspect": "Square",
        "type": "video",
    },
)

POWER_WIDGETS = (
    {
        "label_id": "33060",
        "suffix": "",
        "name": "",
        "widget": "custom",
        "path": "plugin://plugin.video.xtream.strm/?mode=empty_widget",
        "target": "video",
        "aspect": "Square",
        "type": "video",
    },
)

NETFLIX_STYLE_SETTINGS = {
    "colorpalette": "basic",
    "focuscolor.name": "FFE50914",
    "focuscolorotherbar.name": "FFE50914",
    "focuscolor2.name": "FFE50914",
    "selectbarcolor.name": "FFE50914",
    "selectotherbarcolor.name": "FFB20710",
    "squarecolor.name": "FF1A1A1A",
    "squarecolor2.name": "FFE50914",
    "kodilogocolor.name": "FFE50914",
    "kodilogocolorgradient.name": "FFB20710",
    "backgroundbrightness": "35",
    "backgroundbrightnessblur": "25",
    "NetflixTrailerDelay": "5",
}

NETFLIX_STYLE_BOOL_SETTINGS = {
    "homemenu.netflix": True,
    "home.vertical": True,
    "home.vertical.widgets": True,
    "furniture.coloredicons": False,
    "osd.coloredicons": False,
    "tmdbhelper.enablecolors": False,
    "items.focus.glow": False,
    "items.focus.glow.low": False,
    "items.focus.glow.full": False,
    "items.focus.zoom": True,
    "global.showvideo": False,
    "background.video.fix.audio.errors": False,
    "home.netflix.autoplay.trailer": True,
    "home.netflix.autoplay.trailer.custom.window": False,
    "home.netflix.autoplay.trailer.custom.window.force": False,
    "trailer.dont.stop.on.unfocus": False,
    "playtrailerwindowed": False,
    "extended.nowplaying.videowindow": False,
}


def _is_addon_installed(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def _json_rpc(method, params=None):
    payload = {
        "jsonrpc": "2.0",
        "method": method,
        "id": 1,
    }
    if params is not None:
        payload["params"] = params

    response = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        return json.loads(response)
    except Exception:
        return {}


def _get_active_skin():
    data = _json_rpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})
    return data.get("result", {}).get("value", "")


def _set_active_skin(skin_id):
    data = _json_rpc(
        "Settings.SetSettingValue",
        {
            "setting": "lookandfeel.skin",
            "value": skin_id,
        },
    )
    return data.get("result") == "OK"


def _wait_for_addon(addon_id, timeout=90):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _is_addon_installed(addon_id):
            return True
        xbmc.sleep(1000)
    return _is_addon_installed(addon_id)


def _install_and_enable_addon(addon_id, timeout=90):
    if not _is_addon_installed(addon_id):
        xbmc.executebuiltin("InstallAddon(%s)" % addon_id, True)

    if not _wait_for_addon(addon_id, timeout=timeout):
        return False

    try:
        xbmcaddon.Addon(addon_id)
    except Exception:
        xbmc.executebuiltin("EnableAddon(%s)" % addon_id, True)

    return _wait_for_addon(addon_id, timeout=10)


def _open_skin_settings():
    xbmc.executebuiltin("ActivateWindow(interfacesettings)")
    xbmc.sleep(500)
    xbmc.executebuiltin("SetFocus(30)")


def _yesno(title, message="", nolabel="Abbrechen", yeslabel="Ja"):
    return xbmcgui.Dialog().yesno(title, message, nolabel=nolabel, yeslabel=yeslabel)


def _translate(path):
    return xbmcvfs.translatePath(path)


def _ensure_parent(path):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)


def _read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def _write_text(path, text):
    _ensure_parent(path)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def _write_xml(path, root):
    _ensure_parent(path)
    tree = ET.ElementTree(root)
    try:
        ET.indent(tree, space="    ")
    except AttributeError:
        pass
    tree.write(path, encoding="UTF-8", xml_declaration=True)


def _skinshortcuts_profile_path(filename):
    return _translate("special://profile/addon_data/%s/%s" % (SKINSHORTCUTS_ID, filename))


def _skin_profile_settings_path():
    return _translate("special://profile/addon_data/%s/settings.xml" % ARCTIC_ZEPHYR_RELOADED_ID)


def _kodi_database_folder():
    return _translate("special://profile/Database")


def _kodi_thumbnails_folder():
    return _translate("special://profile/Thumbnails")


def _skin_setup_state_path():
    return _translate("%s/%s" % (ADDON_PROFILE, SKIN_SETUP_STATE_FILE))


def _skin_default_mainmenu_path():
    return _translate("special://home/addons/%s/shortcuts/mainmenu.DATA.xml" % ARCTIC_ZEPHYR_RELOADED_ID)


def _load_json_list(path):
    if not os.path.exists(path):
        return []
    try:
        data = json.loads(_read_text(path))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_json_list(path, data):
    _write_text(path, json.dumps(data, indent=4))


def _load_json_object(path):
    if not os.path.exists(path):
        return {}
    try:
        data = json.loads(_read_text(path))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_json_object(path, data):
    _write_text(path, json.dumps(data, indent=4, sort_keys=True))


def _set_shortcut_property(properties, label_id, name, value, group="mainmenu"):
    properties[:] = [
        item for item in properties
        if not (
            len(item) >= 4
            and item[0] == group
            and item[1] == label_id
            and item[2] == name
        )
    ]
    properties.append([group, label_id, name, value])


def _configure_mainmenu_visibility():
    user_path = _skinshortcuts_profile_path("mainmenu.DATA.xml")
    source_path = user_path if os.path.exists(user_path) else _skin_default_mainmenu_path()
    root = ET.parse(source_path).getroot()

    for shortcut in root.findall("shortcut"):
        default_id = shortcut.findtext("defaultID")
        label = shortcut.findtext("label") or ""
        label_normalized = label.strip().lower()
        disabled = shortcut.find("disabled")
        if default_id in MAINMENU_ALLOWED_DEFAULT_IDS or label_normalized in MAINMENU_ALLOWED_LABELS:
            if disabled is not None:
                shortcut.remove(disabled)
        elif disabled is None:
            ET.SubElement(shortcut, "disabled").text = "True"

    _write_xml(user_path, root)


def _configure_widgets():
    properties_path = _skinshortcuts_profile_path("%s.properties" % ARCTIC_ZEPHYR_RELOADED_ID)
    properties = _load_json_list(properties_path)
    properties = [
        item for item in properties
        if not (
            len(item) >= 3
            and item[0] == "mainmenu"
            and item[1] == "33060"
            and item[2].startswith("widget")
        )
    ]

    for widget in MOVIE_WIDGETS + TV_WIDGETS + SETTINGS_WIDGETS + POWER_WIDGETS:
        label_id = widget["label_id"]
        suffix = widget["suffix"]
        if suffix:
            _set_shortcut_property(properties, label_id, "widgetEnable%s" % suffix, "yes")

        _set_shortcut_property(properties, label_id, "widget%s" % suffix, widget["widget"])
        _set_shortcut_property(properties, label_id, "widgetName%s" % suffix, widget["name"])
        _set_shortcut_property(properties, label_id, "widgetPath%s" % suffix, widget["path"])
        _set_shortcut_property(properties, label_id, "widgetTarget%s" % suffix, widget["target"])
        _set_shortcut_property(properties, label_id, "widgetaspect%s" % suffix, widget["aspect"])
        widget_type = widget.get("type")
        if widget_type is None:
            widget_type = "movies" if label_id == "20342" else "tvshows"
        _set_shortcut_property(properties, label_id, "widgetType%s" % suffix, widget_type)

    _save_json_list(properties_path, properties)


def _setting_node(root, setting_id, setting_type):
    node = root.find("./setting[@id='%s']" % setting_id)
    if node is None:
        node = ET.SubElement(root, "setting", {"id": setting_id, "type": setting_type})
    else:
        node.set("type", setting_type)
    return node


def _configure_netflix_colors():
    for setting_id, value in NETFLIX_STYLE_SETTINGS.items():
        xbmc.executebuiltin("Skin.SetString(%s,%s)" % (setting_id, value))

    for setting_id, value in NETFLIX_STYLE_BOOL_SETTINGS.items():
        if value:
            xbmc.executebuiltin("Skin.SetBool(%s)" % setting_id)
        else:
            xbmc.executebuiltin("Skin.Reset(%s)" % setting_id)

    settings_path = _skin_profile_settings_path()
    if os.path.exists(settings_path):
        root = ET.parse(settings_path).getroot()
    else:
        root = ET.Element("settings", {"version": "2"})

    for setting_id, value in NETFLIX_STYLE_SETTINGS.items():
        _setting_node(root, setting_id, "string").text = value

    for setting_id, value in NETFLIX_STYLE_BOOL_SETTINGS.items():
        _setting_node(root, setting_id, "bool").text = "true" if value else "false"

    _write_xml(settings_path, root)


def _remove_file(path):
    try:
        if os.path.exists(path):
            os.remove(path)
            return True
    except Exception as exc:
        xbmc.log("[IPTV Addon] Skin Cache Datei konnte nicht geloescht werden: %s | %s" % (path, exc), xbmc.LOGWARNING)
    return False


def _clear_directory_files(path):
    removed = 0
    if not os.path.isdir(path):
        return removed

    for root, _dirs, files in os.walk(path):
        for filename in files:
            if _remove_file(os.path.join(root, filename)):
                removed += 1

    return removed


def _clear_texture_cache():
    removed = 0
    database_folder = _kodi_database_folder()
    if os.path.isdir(database_folder):
        for filename in os.listdir(database_folder):
            if filename.startswith("Textures") and filename.endswith(".db"):
                if _remove_file(os.path.join(database_folder, filename)):
                    removed += 1

    removed += _clear_directory_files(_kodi_thumbnails_folder())
    xbmc.log("[IPTV Addon] Skin Texture Cache bereinigt: " + str(removed), xbmc.LOGINFO)
    return removed


def _reload_skinshortcuts_and_skin():
    xbmcgui.Window(10000).setProperty("skinshortcuts-reloadmainmenu", "True")
    xbmc.executebuiltin(
        "RunScript(script.skinshortcuts,type=buildxml&mainmenuID=300&group=mainmenu|x1111|x1112|x1113|x1114|x1115|x1116|x1117|x1118|x1119|powermenu&levels=6)",
        True,
    )
    xbmc.executebuiltin("ReloadSkin()")


def _mark_skin_setup_applied():
    version = xbmcaddon.Addon().getAddonInfo("version")
    _save_json_object(_skin_setup_state_path(), {"addon_version": version, "applied_at": int(time.time())})


def _apply_arctic_zephyr_reloaded_settings(clear_cache=True):
    _configure_mainmenu_visibility()
    _configure_widgets()
    _configure_netflix_colors()
    if clear_cache:
        _clear_texture_cache()
    _reload_skinshortcuts_and_skin()
    _mark_skin_setup_applied()


def install_youtube_addon(show_dialog=True):
    if _install_and_enable_addon(YOUTUBE_ADDON_ID):
        if show_dialog:
            xbmcgui.Dialog().notification(
                YOUTUBE_ADDON_NAME,
                "Addon ist installiert",
                xbmcgui.NOTIFICATION_INFO,
                4000,
            )
        return True

    if show_dialog:
        xbmcgui.Dialog().ok(
            YOUTUBE_ADDON_NAME,
            "Das YouTube-Addon konnte nicht installiert werden.",
            "Bitte pruefe, ob das offizielle Kodi-Repository aktiviert ist.",
        )
    return False


def setup_arctic_zephyr_reloaded(show_dialog=False):
    if not _install_and_enable_addon(ARCTIC_ZEPHYR_RELOADED_ID):
        if show_dialog:
            xbmcgui.Dialog().ok(
                ARCTIC_ZEPHYR_RELOADED_NAME,
                "Der Skin konnte nicht installiert werden.",
                "Bitte pruefe, ob das offizielle Kodi-Repository aktiviert ist.",
            )
        return False

    if _get_active_skin() != ARCTIC_ZEPHYR_RELOADED_ID:
        _set_active_skin(ARCTIC_ZEPHYR_RELOADED_ID)
        xbmc.sleep(1500)

    if _get_active_skin() != ARCTIC_ZEPHYR_RELOADED_ID:
        if show_dialog:
            _open_skin_settings()
            xbmcgui.Dialog().ok(
                ARCTIC_ZEPHYR_RELOADED_NAME,
                "Kodi hat den Skin-Wechsel nicht automatisch uebernommen.",
                "Die Skin-Einstellungen wurden geoeffnet. Bitte Arctic: Zephyr - Reloaded dort auswaehlen.",
            )
        return False

    _apply_arctic_zephyr_reloaded_settings(clear_cache=True)
    if show_dialog:
        xbmcgui.Dialog().notification(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Skin, Widgets und Auto-Trailer eingerichtet",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
    return True


def apply_arctic_zephyr_reloaded_after_update():
    if not _is_addon_installed(ARCTIC_ZEPHYR_RELOADED_ID):
        return False

    if _get_active_skin() != ARCTIC_ZEPHYR_RELOADED_ID:
        return False

    version = xbmcaddon.Addon().getAddonInfo("version")
    state = _load_json_object(_skin_setup_state_path())
    if state.get("addon_version") == version:
        return False

    try:
        _apply_arctic_zephyr_reloaded_settings(clear_cache=True)
        xbmc.log("[IPTV Addon] Arctic Zephyr Skin nach Addon-Update aktualisiert: " + version, xbmc.LOGINFO)
        return True
    except Exception as exc:
        xbmc.log("[IPTV Addon] Arctic Zephyr Auto-Update fehlgeschlagen: %s" % exc, xbmc.LOGERROR)
        return False


def configure_arctic_zephyr_reloaded():
    dialog = xbmcgui.Dialog()

    if not _is_addon_installed(ARCTIC_ZEPHYR_RELOADED_ID):
        dialog.ok(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Bitte installiere den Skin zuerst ueber den Arctic-Zephyr-Menuepunkt.",
        )
        return

    confirm = _yesno(
        ARCTIC_ZEPHYR_RELOADED_NAME,
        "Im Hauptmenue bleiben nur Filme, Serien, Einstellungen und Power sichtbar.\n\n"
        "Widgets, dunkle Netflix-Farben, rote Akzente und der Icon-Cache werden gesetzt.\n\n"
        "Soll die Skin-Konfiguration jetzt geschrieben werden?",
        nolabel="Abbrechen",
        yeslabel="Fortfahren",
    )
    if not confirm:
        return

    try:
        _apply_arctic_zephyr_reloaded_settings(clear_cache=True)
        dialog.notification(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Hauptmenue, Widgets, Farben, Hintergrundvideo und Icon-Cache gesetzt",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
    except Exception as exc:
        dialog.ok(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Die Skin-Konfiguration konnte nicht geschrieben werden.",
            str(exc),
        )


def install_arctic_zephyr_reloaded():
    dialog = xbmcgui.Dialog()

    if not _is_addon_installed(ARCTIC_ZEPHYR_RELOADED_ID):
        install = _yesno(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Der Skin wird aus dem offiziellen Kodi-Repository installiert.\n\n"
            "Installation jetzt starten?",
            nolabel="Abbrechen",
            yeslabel="Installieren",
        )
        if not install:
            return

        xbmc.executebuiltin("InstallAddon(%s)" % ARCTIC_ZEPHYR_RELOADED_ID, True)

    if not _wait_for_addon(ARCTIC_ZEPHYR_RELOADED_ID):
        dialog.ok(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Der Skin konnte nicht installiert werden.",
            "Bitte pruefe, ob das offizielle Kodi-Repository aktiviert ist.",
        )
        return

    try:
        xbmcaddon.Addon(ARCTIC_ZEPHYR_RELOADED_ID)
    except Exception:
        xbmc.executebuiltin("EnableAddon(%s)" % ARCTIC_ZEPHYR_RELOADED_ID, True)

    switch = _yesno(
        ARCTIC_ZEPHYR_RELOADED_NAME,
        "Der Skin ist installiert.\n\nJetzt als Kodi-Skin aktivieren?",
        nolabel="Abbrechen",
        yeslabel="Aktivieren",
    )
    if not switch:
        return

    active_skin = _get_active_skin()
    if active_skin == ARCTIC_ZEPHYR_RELOADED_ID:
        dialog.notification(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Skin ist bereits aktiv",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
        return

    changed = _set_active_skin(ARCTIC_ZEPHYR_RELOADED_ID)
    xbmc.sleep(1500)

    if changed and _get_active_skin() == ARCTIC_ZEPHYR_RELOADED_ID:
        dialog.notification(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Skin aktiviert",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
    else:
        _open_skin_settings()
        dialog.ok(
            ARCTIC_ZEPHYR_RELOADED_NAME,
            "Kodi hat den Skin-Wechsel nicht automatisch uebernommen.",
            "Die Skin-Einstellungen wurden geoeffnet. Bitte Arctic: Zephyr - Reloaded dort auswaehlen.",
        )
